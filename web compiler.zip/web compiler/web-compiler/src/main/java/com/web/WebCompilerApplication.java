package com.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//The main entry point of the application
@SpringBootApplication
public class WebCompilerApplication {

	public static void main(String[] args) {
		// SpringApplication.run() method starts the Spring Boot application
		SpringApplication.run(WebCompilerApplication.class, args);
	}

}