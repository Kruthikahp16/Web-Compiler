package com.web.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.web.util.CompileRequest;
import com.web.util.CompileResponse;

@RestController
public class CompilerController {

	// Endpoint for compiling code
    @PostMapping("/compile")
    public CompileResponse compileCode(@RequestBody CompileRequest request) {
        // Extracting language and code from the request
        String language = request.getLanguage().toLowerCase(); // Convert language to lowercase for case-insensitivity
        String code = request.getCode();

        // Mock compilation process
        String compiledCode;
        switch (language) {
            case "solidity":
               
                compiledCode = "Compiled Solidity code: " + code;
                break;
            case "rust":
               
                compiledCode = "Compiled Rust code: " + code;
                break;
            case "motoko":
        
                compiledCode = "Compiled Motoko code: " + code;
                break;
            default:
                // If language is not supported, indicate it
                compiledCode = "Unsupported language";
        }

        return new CompileResponse(compiledCode);
    }
}