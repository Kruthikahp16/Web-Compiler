package com.web.util;

//CompileResponse class represents the response returned by the compiler endpoint
public class CompileResponse {
	private String output;

	public CompileResponse(String output) {
		this.output = output;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}
}